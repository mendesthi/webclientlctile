sap.ui.define([
	'jquery.sap.global',
	"sap/ui/core/mvc/Controller"
], function (jQuery,Controller) {
	"use strict";
    
	return Controller.extend("xxx.FioriContainerApp.controller.Container", {
		onInit: function () {
		}
	});
});